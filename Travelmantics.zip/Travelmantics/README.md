# travemantics
Creating  First Android App with Android Studio and Firebase
How to use Firebase within your app so that you can build great full-stack apps quickly and follow best practices.
